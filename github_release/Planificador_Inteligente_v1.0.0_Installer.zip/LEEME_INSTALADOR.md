# 🚀 Planificador Inteligente - Instalador

## 📋 Contenido del Paquete

Este paquete contiene todo lo necesario para instalar y usar el Planificador Inteligente:

### 📁 Archivos Incluidos
- `PlanificadorInteligente.exe` - Aplicación principal
- `instalar.bat` - Script de instalación automática
- `Ejecutar_Planificador.bat` - Ejecutor directo
- `desinstalar.bat` - Script de desinstalación
- `config.json` - Configuración del sistema
- `plantilla_planificacion.xlsx` - Plantilla de Excel
- `docs/` - Documentación completa

## 🔧 Instalación

### Opción 1: Instalación Automática (Recomendada)
1. Extraer todos los archivos a una carpeta
2. Ejecutar `instalar.bat` como administrador
3. Seguir las instrucciones en pantalla
4. Usar el acceso directo creado en el escritorio

### Opción 2: Instalación Manual
1. Extraer archivos a la carpeta deseada
2. Ejecutar `PlanificadorInteligente.exe` directamente
3. Crear acceso directo manualmente si es necesario

## 📊 Uso del Sistema

### Primeros Pasos
1. Abrir el Planificador Inteligente
2. Descargar la plantilla de Excel
3. Llenar los datos en Excel
4. Cargar el archivo en el sistema
5. Procesar y obtener resultados

### Funcionalidades Principales
- ✅ Procesamiento de archivos Excel
- ✅ Análisis inteligente de procesos
- ✅ Optimización de recursos
- ✅ Generación de reportes
- ✅ Interfaz gráfica amigable
- ✅ Exportación de resultados

## 🛠️ Requisitos del Sistema

- **Sistema Operativo**: Windows 10 o superior
- **Memoria RAM**: 4 GB mínimo (8 GB recomendado)
- **Espacio en Disco**: 500 MB disponibles
- **Software**: Microsoft Excel (opcional, para mejor experiencia)

## 📞 Soporte

### Documentación
- Ver carpeta `docs/` para documentación completa
- `README_USUARIO.md` - Guía de usuario
- `GUIA_INTEGRACION_EXCEL.md` - Guía de Excel

### Resolución de Problemas
1. Verificar que Windows Defender no bloquee la aplicación
2. Ejecutar como administrador si es necesario
3. Verificar que los archivos estén completos
4. Consultar los logs de error en caso de problemas

## 🔄 Desinstalación

Para desinstalar el programa:
1. Ejecutar `desinstalar.bat`
2. Confirmar la desinstalación
3. Los archivos y accesos directos serán eliminados

## 📈 Versión

**Versión**: 1.0.0
**Fecha**: 2024
**Estado**: Producción

## 🏆 Características

- **Multiplataforma**: Funciona en Windows
- **Sin dependencias**: No requiere Python instalado
- **Interfaz intuitiva**: Fácil de usar
- **Procesamiento rápido**: Optimizado para rendimiento
- **Documentación completa**: Guías y manuales incluidos

¡Gracias por usar el Planificador Inteligente! 🚀
